# ---------------------------------------------------------------------------
# Consensus-MCMC preprocessing for BAST
# Creates per-shard init_val + hyperpar files (no sampling)
# ---------------------------------------------------------------------------

## 0. Library & path setup ----
# my_lib_path <- ""        # custom lib
# .libPaths(my_lib_path)

library(DP.RST)
# library(rlang)
library(MASS)
library(igraph)
library(fields)
library(mclust)
library(dplyr)
library(purrr)

## 1. Parameters you may tweak ----
set.seed(42)           # reproducibility

S_plus1   <- 601         # total shards  (S anchor + S-1 regular)
anchor_id <- 1         # which shard is the anchor
M         <- 10        # # parallel chains (same as later PT runs)
temp      <- seq(0.1, 1, length.out = M)   # PT ladder
out_dir   <- "~/Desktop/DP-RST-workload/HD_Mouse_Embryo/BAST_Shards"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

## 2. Load data ----
load("~/Desktop/DP-RST-workload/HD_Mouse_Embryo/Processed_Data/MouseEmbryo_HD_merged_data.RData")

Y_sample <- merged_data[, c("PC1", "PC2", "PC3")]          # three expression variables
loc <- merged_data[, c("x", "y")]  

coords   <- apply(loc, 2, scale)             # z-score coords
Y_std    <- apply(Y_sample, 2, scale)        # z-score expr


## Shard construction ----
n          <- nrow(Y_std)
shard_ids  <- sample(rep(1:S_plus1, length.out = n))
anchor_idx <- which(shard_ids == anchor_id)
shard_idxs <- lapply(setdiff(1:S_plus1, anchor_id),
                     function(s) which(shard_ids == s))
shards     <- lapply(shard_idxs, function(idx) sort(c(idx, anchor_idx)))

## ---- Save the full anchor set for later merging ----
anchor_points <- list(
  idx  = anchor_idx,                 # indices in the original order
  coord = coords[anchor_idx, , drop = FALSE]  # scaled x-y positions
)
saveRDS(anchor_points,
        file = file.path(out_dir, "AnchorPoints.rds"))
message("🔖  Saved global anchor points → ", file.path(out_dir, "AnchorPoints_Brain.rds"))

gen2dMesh_NoBnd <- function(coords, bnd = NULL, ...) {
  n <- nrow(coords)
  # ---- NO BOUNDARY -----------------------------------------------------
  mesh <- fdaPDE::create.mesh.2D(coords, ...)     # interior points only
  mesh$n_int     <- n                     # all nodes are interior
  mesh$bnd_edges <- rep(FALSE, nrow(mesh$edges))
  return(mesh)
}


## 5. Helper: preprocess one shard ----
preprocess_shard <- function(idx, shard_id) {
  y_shard   <- Y_std[idx, , drop = FALSE]
  loc_shard <- coords[idx, , drop = FALSE]
  
  n_s       <- nrow(y_shard)
  p <- ncol(Y_std)
  
  ## Mesh & constrained Delaunay tree ----
  mesh_shard <- gen2dMesh_NoBnd(loc_shard)
  g_shard    <- constrainedDentri(n_s, mesh_shard)
  E(g_shard)$eid <- seq_len(ecount(g_shard))
  V(g_shard)$vid <- seq_len(vcount(g_shard))
  g_mst      <- mst(g_shard) |> delete_edge_attr("weight")
  g_shard    <- delete_edge_attr(g_shard, "weight")
  
  graph0 <- g_shard         # 1️⃣ keep a copy under the exact name fitBAST expects
  
  ## --- Graph-based clustering & centroids ------------------------------------
  # Choose which graph to measure geodesics on:
  #   * MST  (fast, guarantees connectivity)  -> g_mst
  #   * Full constrained triangulation        -> g_shard
  g_dist  <- distances(g_mst)                 # (n_s × n_s) matrix
  
  # Replace Inf with 2×max finite distance
  finite_max <- max(g_dist[is.finite(g_dist)])
  g_dist[!is.finite(g_dist)] <- 2 * finite_max
  
  # Hierarchical clustering
  hc           <- fastcluster::hclust(as.dist(g_dist), method = "ward.D2")
  num_clusters <- 50
  clust_s      <- cutree(hc, k = num_clusters)           # vector length n_s
  k_max_s      <- length(unique(clust_s))
  
  # Centroids (mean expression per cluster, measured on **shard** data)
  centroids <- vapply(sort(unique(clust_s)),
                      function(k) colMeans(y_shard[clust_s == k, , drop = FALSE]),
                      numeric(ncol(y_shard)))
  centroids <- t(centroids)              # k_max_s × p; rownames = cluster id
  
  ## cluster labels re-indexed to 1:K ----
  
  ## -------- Initial values (same structure DP.RST expects) --------
  cluster_mat <- matrix(rep(clust_s, M), ncol = M)
  mu_list     <- vector("list", M)
  mu_teams    <- vector("list", M)
  sigmasq_y   <- vector("list", M)
  mst_list    <- vector("list", M)
  
  for (m in seq_len(M)) {
    mu_list[[m]]      <- centroids
    sigmasq_y[[m]]    <- cov(y_shard)
    mst_list[[m]]     <- g_mst
  }
  
  init_val <- list(
    trees        = mst_list,
    mu           = mu_list,
    cluster      = cluster_mat,
    sigmasq_y    = sigmasq_y
  )
  
  ## -------- Hyper-parameters --------
  
  hyperpar <- list(
    sigmasq_mu = (0.5/(2*sqrt(1)))^2,
    lambda_s   = diag(1, p),
    nu         = p,
    M          = M,
    k_max      = k_max_s,
    lambda_k   = 20
  )
  
  ## -----------------------------------------------------------
  anchor_local <- which(idx %in% anchor_idx)   # ← add this line
  ## (OPTIONAL but recommended) also keep the global indices:
  idx_global   <- idx                           # ← add this line
  ## -----------------------------------------------------------
  
  ## Save shard bundle ----
  save(list = c("y_shard", "loc_shard", "graph0",
                "init_val", "hyperpar", "clust_s",
                "anchor_local", "idx_global"),
       file = file.path(out_dir,
                        sprintf("Shard_%s_Preproc_BAST.RData", shard_id))
  )
  message(sprintf("[Shard %s] → saved %s/Shard_%s_Preproc_BAST.RData",
                  shard_id, out_dir, shard_id))
}

## 6. Run preprocessing over all (S_plus1-1) regular shards ----
#purrr::walk2(shards, seq_along(shards), preprocess_shard)

for (sid in seq_along(shards)) {
  message("Starting shard ", sid)
  preprocess_shard(shards[[sid]], sid)
}

message("✅  All shard preprocessing files written to: ", out_dir)
